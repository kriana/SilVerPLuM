﻿namespace StardewModdingAPI.Entities
{
    internal class SNpc
    {
    }
}