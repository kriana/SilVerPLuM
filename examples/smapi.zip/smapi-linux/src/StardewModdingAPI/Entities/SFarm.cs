﻿namespace StardewModdingAPI.Entities
{
    internal class SFarm
    {
    }
}