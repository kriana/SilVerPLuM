﻿namespace StardewModdingAPI.Entities
{
    internal class SFarmAnimal
    {
    }
}