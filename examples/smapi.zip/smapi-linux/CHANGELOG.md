# Change Log

## [Unreleased](https://github.com/CLxS/SMAPI/tree/HEAD)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.40.0...HEAD)

## [0.40.0](https://github.com/CLxS/SMAPI/tree/0.40.0) (2016-04-05)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.39.7...0.40.0)

## [0.39.7](https://github.com/CLxS/SMAPI/tree/0.39.7) (2016-04-04)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.39.6...0.39.7)

## [0.39.6](https://github.com/CLxS/SMAPI/tree/0.39.6) (2016-04-01)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.39.5...0.39.6)

## [0.39.5](https://github.com/CLxS/SMAPI/tree/0.39.5) (2016-03-30)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.39.4...0.39.5)

## [0.39.4](https://github.com/CLxS/SMAPI/tree/0.39.4) (2016-03-29)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.39.3...0.39.4)

## [0.39.3](https://github.com/CLxS/SMAPI/tree/0.39.3) (2016-03-28)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.39.2...0.39.3)

## [0.39.2](https://github.com/CLxS/SMAPI/tree/0.39.2) (2016-03-23)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.39.1...0.39.2)

## [0.39.1](https://github.com/CLxS/SMAPI/tree/0.39.1) (2016-03-23)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.8...0.39.1)

## [0.38.8](https://github.com/CLxS/SMAPI/tree/0.38.8) (2016-03-23)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.7...0.38.8)

## [0.38.7](https://github.com/CLxS/SMAPI/tree/0.38.7) (2016-03-23)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.6...0.38.7)

## [0.38.6](https://github.com/CLxS/SMAPI/tree/0.38.6) (2016-03-22)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.5...0.38.6)

## [0.38.5](https://github.com/CLxS/SMAPI/tree/0.38.5) (2016-03-22)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.4...0.38.5)

## [0.38.4](https://github.com/CLxS/SMAPI/tree/0.38.4) (2016-03-21)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.3...0.38.4)

## [0.38.3](https://github.com/CLxS/SMAPI/tree/0.38.3) (2016-03-21)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.2...0.38.3)

## [0.38.2](https://github.com/CLxS/SMAPI/tree/0.38.2) (2016-03-21)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.0...0.38.2)

## [0.38.0](https://github.com/CLxS/SMAPI/tree/0.38.0) (2016-03-20)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.38.1...0.38.0)

## [0.38.1](https://github.com/CLxS/SMAPI/tree/0.38.1) (2016-03-20)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.37.3...0.38.1)

## [0.37.3](https://github.com/CLxS/SMAPI/tree/0.37.3) (2016-03-08)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.37.2...0.37.3)

## [0.37.2](https://github.com/CLxS/SMAPI/tree/0.37.2) (2016-03-07)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.37.1...0.37.2)

## [0.37.1](https://github.com/CLxS/SMAPI/tree/0.37.1) (2016-03-06)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.36...0.37.1)

## [0.36](https://github.com/CLxS/SMAPI/tree/0.36) (2016-03-04)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.37...0.36)

## [0.37](https://github.com/CLxS/SMAPI/tree/0.37) (2016-03-04)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.35...0.37)

## [0.35](https://github.com/CLxS/SMAPI/tree/0.35) (2016-03-02)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.34...0.35)

## [0.34](https://github.com/CLxS/SMAPI/tree/0.34) (2016-03-02)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.33...0.34)

## [0.33](https://github.com/CLxS/SMAPI/tree/0.33) (2016-03-02)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.32...0.33)

## [0.32](https://github.com/CLxS/SMAPI/tree/0.32) (2016-03-02)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.31...0.32)

## [0.31](https://github.com/CLxS/SMAPI/tree/0.31) (2016-03-02)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/0.3...0.31)

## [0.3](https://github.com/CLxS/SMAPI/tree/0.3) (2016-03-01)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/Alpha0.2...0.3)

## [Alpha0.2](https://github.com/CLxS/SMAPI/tree/Alpha0.2) (2016-02-29)
[Full Changelog](https://github.com/CLxS/SMAPI/compare/Alpha0.1...Alpha0.2)

## [Alpha0.1](https://github.com/CLxS/SMAPI/tree/Alpha0.1) (2016-02-28)