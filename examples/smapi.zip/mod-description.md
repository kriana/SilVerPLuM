# Stardew Modding Application Programming Interface

SMAPI (Stardew Modding Application Programming Interface) is a tool to help modders make changes to Stardew. It is a standalone executable which goes alongside your Stardew.exe. 
