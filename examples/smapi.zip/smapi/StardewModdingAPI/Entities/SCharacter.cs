﻿namespace StardewModdingAPI.Entities
{
    internal class SCharacter
    {
    }
}