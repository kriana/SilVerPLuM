"Drain the lakes, rivers, and ponds! Chisel back the cliffs! Cut down those trees! Trim the grass! ALL THE SPACE IS WANTED!"​

If you can relate to this...slightly over enthusiastic hypothetical farmer, then you've come to the right place. This is the most stripped down version of the maps, opening up as much farming space as possible without feeling like the map has been made completely unrecognizable [in my opinion]. 
