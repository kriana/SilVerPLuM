"Drain the lakes, rivers, and ponds! Chisel back the cliffs! Cut down those trees! Trim the grass! ALL THE SPACE IS WANTED!"​

If you can relate to this...slightly over enthusiastic hypothetical farmer, then you've come to the right place. This is the most stripped down version of the maps, opening up as much farming space as possible without feeling like the map has been made completely unrecognizable [in my opinion]. 

## The default farm
<a href="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_farm.png"><img src="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_farm.png" width="300"></a>

## The wilderness map
<a href="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_farm.png"><img src="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_wilderness_farm.png" width="300"></a>

## The forest map
<a href="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_farm.png"><img src="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_forest_farm.png" width="300"></a>

## The hilltop map
<a href="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_farm.png"><img src="https://raw.githubusercontent.com/rumangerst/SilVerPLuM/master/examples/renovated-farms/screenshot_hilltop_farm.png" width="300"></a>
