﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Pathoschild.LookupAnything")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Pathoschild.LookupAnything")]
[assembly: AssemblyCopyright("Copyright © 2016")]
[assembly: Guid("2a9c0811-b2d2-474a-a84c-ddeb16206a62")]
[assembly: AssemblyVersion("1.5.0.0")]
[assembly: AssemblyFileVersion("1.5.0.0")]
