#!/bin/bash

mono TestLauncher.exe 
